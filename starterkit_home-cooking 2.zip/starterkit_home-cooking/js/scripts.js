// ======================================================
// js / scripts.js
// ======================================================

// When document is ready
// ======================================================

/**
 * Execute all my functions.
 *
 * @param {*} data : Your aunt's data.
 */
var dynamicActions = function(data) {
  $(document).ready(function() {
    updateDocumentTitle();
    showArticleF(data);


    // function2()...
    // function3()...
    // function4()...
    // etc.
  });
};

// My functions
// ======================================================

/**
 * Update the document's title by using the provided data
 * from my aunt.
 */
var updateDocumentTitle = function() {
  // Some code...
  
document.getElementById("title").innerHTML = "Lilou";
};

var showArticleF = function(data) {

for(var i=1;i<=3;i++){

  document.getElementById("content"+i).innerHTML = data.articles[i-1].content;
}

for(var i=1;i<=3;i++){

  document.getElementById("subT"+i).innerHTML = data.articles[i-1].subtitle;
}
for(var i=1;i<=3;i++){

  document.getElementById("title"+i).innerHTML = data.articles[i-1].title;
}


};
